import { Component,Inject} from '@angular/core';
import {Http} from '@angular/http';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  data;sdata;ssdata;
  constructor(@Inject(ActivatedRoute)public aa,@Inject(Http) public obj){}

  ngOnInit(){


// getting Category Menu///////////////

this.obj.get("homeserver/user_cat").subscribe(
  dt=>{
    this.data=JSON.parse(dt._body)
   // alert(this.data)
  })
 this.fun2()
}


// getting subcat in cat dropdown///////////

fun2(){
  this.obj.get("homeserver/user_subcat").subscribe(
    dtt=>{
      this.sdata=JSON.parse(dtt._body)
     // alert(this.sdata)
    })

 this.fun3()
}

// getting subsubcat in cat dropdown///////////
fun3(){
alert("hii")
this.obj.get("homeserver/user_subsubcat").subscribe(
 dttt=>{
   this.ssdata=JSON.parse(dttt._body)
  alert(this.ssdata)
 }
)
}




}



