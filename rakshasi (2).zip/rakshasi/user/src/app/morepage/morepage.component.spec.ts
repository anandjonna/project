import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MorepageComponent } from './morepage.component';

describe('MorepageComponent', () => {
  let component: MorepageComponent;
  let fixture: ComponentFixture<MorepageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MorepageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MorepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
