import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-morepage',
  templateUrl: './morepage.component.html',
  styleUrls: ['./morepage.component.css']
})
export class MorepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
