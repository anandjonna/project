import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';
import { AppComponent } from './app.component';
import {RouterModule,Routes} from "@angular/router";
import { HomePageComponent } from './homepage/homepage.component';
import { MorepageComponent } from './morepage/morepage.component';
import { ProductpageComponent } from './productpage/productpage.component';


var obj:Routes=[{
  
  path:"",component:HomePageComponent
  },{
    path:"mr",component:MorepageComponent
  },

  {
    path:"pr",component:ProductpageComponent
  },
]

 var rout=RouterModule.forRoot(obj);



@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    MorepageComponent,
    ProductpageComponent
  ],
  imports: [
    BrowserModule,HttpModule,rout
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
