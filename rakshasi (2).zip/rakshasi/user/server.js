exp=require("express");
bp=require("body-parser");
app=exp()
app.use(bp.json())
home_server=require("./myserver/homeserver")
product_detail=require("./myserver/productdetail")
app.use("/homeserver",home_server)
app.use("/productdetails",product_detail)
app.listen(4000);
console.log("server started port no 4000")
