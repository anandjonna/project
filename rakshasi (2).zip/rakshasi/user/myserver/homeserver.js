exp=require("express")
mj=require("mongojs")

rout=exp.Router();

conn=mj("mongodb://localhost:27017/raji")

rout.get("/user_cat",function(req,res){
    conn.tbl_cat.find(function(err,result){
        res.send(result)
    })
})

rout.get("/user_subcat",function(req,res){
    conn.tbl_subcat.find(function(err,result){
        res.send(result)
    })
})

rout.get("/user_subsubcat",function(req,res){
    conn.tbl_subsubcat.find(function(err,result){
        res.send(result)
    })
})
module.exports=rout;