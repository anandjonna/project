exp=require("express")
mj=require("mongojs")

rout=exp.Router();

conn=mj("mongodb://localhost:27017/raji")

//getting data from db//
rout.post("/get_prodata",function(req,res){
    ob=req.body
    console.log(ob)
    conn.tbl_products.find({subsubcatid:ob._id},function(err,result){
        res.send(result)
    })
   
})
module.exports=rout;