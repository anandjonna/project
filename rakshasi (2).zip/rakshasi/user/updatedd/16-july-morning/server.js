exp=require("express")

mj=require("mongojs")
conn=mj("mongodb://localhost:27017/rajidb")
bp=require("body-parser")
app=exp()
app.use(bp.json())



cat_ref = require("./myfiles/cat_serverfiles")
subcat_ref = require("./myfiles/subcat_serverfiles")
subsubcat_ref = require("./myfiles/subsubcat_serverfiles")
brand_ref = require("./myfiles/brand_serverfiles")
product_ref = require("./myfiles/product_serverfiles")
app.use("/catserverfile", cat_ref)
app.use("/subcatserverfile", subcat_ref)
app.use("/subsubcatserverfile", subsubcat_ref)
app.use("/brandserverfile", brand_ref)
app.use("/productserverfile", product_ref)
app.listen(4100)
console.log("running through 4100")


/*
*/