exp=require("express")
rt=exp.Router()

mj=require("mongojs")
conn=mj("mongodb://localhost:27017/rajidb")

//Getting dropdown caterory///
rt.get("/get_catdata_ssc1",function(req,res){
    conn.tbl_cat.find(function(err,result){
        res.send(result)
    })
})


//Getting dropdown subcaterory///
rt.post("/get_subcatdata_ssb1",function(req,res){
    ob=req.body
    conn.tbl_subcat.find({catid:ob.catid},function(err,result){
        res.send(result)
    })
})


module.exports=rt;