import { Component, OnInit,Inject } from '@angular/core';
import {Http} from '@angular/http'

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  drpcat;drpsubcat;drpsubsubcat;drpbrand;colrprdt;qtyprdt;ratprdt;txtprdt;
  constructor(@Inject (Http) public ob) { }

/// insert in drp cat data//
catdata;
  fun_cat(){
   
    this.ob.get("productserverfile/cget").subscribe(res=>{
      //alert(res._body)
      this.catdata=JSON.parse(res._body)
      
    })
  }

// insert drp in subcat//
  subcatdata;
  fun_subcat(){
   // alert("bvmnb")
    this.ob.get("productserverfile/sget").subscribe(res=>{
      //alert("bbbbbb")
      this.subcatdata=JSON.parse(res._body)
    })
  }

//insert drp in subsubcat data//

SScatdata;
fun_subsubcat(){
  //alert("hi")
  this.ob.get("productserverfile/sscat_get").subscribe(res=>{
this.SScatdata=JSON.parse(res._body)
alert(this.SScatdata)
  })
}


//insert drp brand data//
branddata;
fun_brand(){
  //alert("hi")
  this.ob.get("productserverfile/brand_get").subscribe(res=>{
this.branddata=JSON.parse(res._body)
alert(this.branddata)
  })
}

//insert product name//

product_ins(){
  var productdata={pname:this.txtprdt,catname:this.drpcat,subcat:this.drpsubcat, subsubcat:this.drpsubsubcat,brandid:this.drpbrand,pcolour:this.colrprdt,pquantity:this.qtyprdt,prating:this.ratprdt}
  this.ob.post("productserverfile/ins_product",productdata).subscribe(this.insproduct)

}
insproduct=(res)=>{
  alert(res._body)
  this.txtprdt=""
  var form_ref=<HTMLFormElement>document.getElementById("fm1")
  form_ref.submit()

}


  ngOnInit() {
    this.fun_cat()
    this.fun_subcat()
    this.fun_subsubcat()
    this.fun_brand()
  var url=(document.URL)
  var rs=url.split("?")
    var iname=rs[1].split("=")
    var img=(iname[1])
    alert(img)
    var imgname={image:img}
    this.ob.post("productserverfile/insert_img",imgname).subscribe(ig=>{
      alert(ig._body)
    })
  }

}
