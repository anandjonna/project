import { Component, OnInit, Inject } from '@angular/core';
import {Http} from '@angular/http';

@Component({
  selector: 'app-subsubcat',
  templateUrl: './subsubcat.component.html',
  styleUrls: ['./subsubcat.component.css']
})
export class SubsubcatComponent implements OnInit {

  constructor(@Inject (Http) public ob) { }


//dropdown insert catdata//
catdata;
  fun_cat(){
    //alert("hiu")
    this.ob.get("subsubcatfile/cget").subscribe(res=>{
      //alert(res._body)
      this.catdata=JSON.parse(res._body)
      
    })
  }



//dropdown getting subcat//
subcatdata;
fun_subcat(){
  var obj={cid:this.drpcat}
  this.ob.post("subsubcatfile/subget",obj).subscribe(res=>{
    //alert(res._body)
    this.subcatdata=JSON.parse(res._body)
    
  })
}


// insert data in subsubcat text box//
txtsubsubcat;drpcat;drpsubcat;

fun_ins_subsubcat(){
  
  var ob={catname:this.drpcat,subcat:this.drpsubcat, subsubcat:this.txtsubsubcat}
  this.ob.post("subsubcatfile/insert",ob).subscribe(res=>{
    alert(res._body)
    this.fun_getSScatdata()
  })
}

ssc;
fun_getSScatdata(){
 // alert("bnjn")
 this.ob.get("subsubcatfile/sscat").subscribe(res=>{
   this.ssc=JSON.parse(res._body)
   console.log(this.ssc)
 })


}
  ngOnInit() {
    this.fun_cat()
    this.fun_subcat()
    this.fun_getSScatdata()
  }

    

}
