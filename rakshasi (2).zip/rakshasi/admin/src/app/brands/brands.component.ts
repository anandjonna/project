import { Component, OnInit,Inject } from '@angular/core';
import {Http} from "@angular/http"

@Component({
  selector: 'app-brands',
  templateUrl: './brands.component.html',
  styleUrls: ['./brands.component.css']
})
export class BrandsComponent implements OnInit {

  constructor(@Inject(Http) public obj) { }
  txtbrand;
  fun_ins_brand(){
    var obj={brandname:this.txtbrand}
  alert(this.txtbrand)
    this.obj.post("brandserverfile/ins_brand", obj).subscribe(this.cback1)
    
  }
  cback1=(obj)=>{
    alert(obj._body)
    this.txtbrand=""
    this.fun_get_brand()
     
  }

  brandss;
  fun_get_brand(){
    this.obj.get("brandserverfile/get_brand").subscribe(this.cback2)
  }
  cback2=(obj)=>{
    this.brandss=JSON.parse(obj._body)
  }
  ngOnInit() {
    this.fun_get_brand()
  }

}
