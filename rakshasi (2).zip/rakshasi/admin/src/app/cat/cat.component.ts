import { Component, OnInit,Inject } from '@angular/core';
import {Http} from "@angular/http"

@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {
txt1=""
data;
tmp=0;
txt2;oldob;a;

  constructor(@Inject(Http) public obj) { }
  //insert in data in caterory///

  fun_ins_cat(){
  var obj={catname:this.txt1}
  alert(this.txt1)
    this.obj.post("catserverfile/ins_cat", obj).subscribe(this.cback1)
    
  }
cback1=(obj)=>{
 alert(obj._body)
 this.txt1=""
 this.fun_get_data()
  
}

/// getting the data///
fun_get_data(){
  this.obj.get("catserverfile/get_cat").subscribe(this.cback2)
}

cback2=(obj)=>{
  this.data=JSON.parse(obj._body)
}

// update code///
funupdate(obj2){
  this.tmp=obj2._id
  this.txt2=obj2.catname
  this.oldob={_id:this.tmp,catname:obj2.catname}
    
}

/// save code ///
funsave(){
  var newob={_id:this.tmp,catname:this.txt2,active:1}
var arr=[this.oldob, newob]
console.log(arr)
this.obj.post("catserverfile/save",arr).subscribe(dt=>{
alert(dt._body)
this.fun_get_data();
})
this.tmp=0

}

/// inactive  code///

funinactive(obj1){
  this.obj.post("catserverfile/catinactive",obj1).subscribe(
    dt=>{
      this.a=dt._body
          })
       this.fun_get_data() 

}

/// active code///
funactive(obj5){
  this.obj.post("catserverfile/catactive",obj5).subscribe(
    dt=>{
      this.a=dt._body
         })
        this.fun_get_data()

}


  ngOnInit() {
    this.fun_get_data()
    
  }

}
/*
  cback1=(obj)=>{
  alert(obj._body)
  this.txt1=""
  this.fun_get_data()
  }
  
  fun_get_data(){
    this.obj.get("cat_file_ref/get_cat").subscribe(this.cback2)
  }
  cback2=(obj)=>{
    this.data=JSON.parse(obj._body)
  }
 
  ngOnInit() {
    this.fun_get_data()
   
  }

}

*/