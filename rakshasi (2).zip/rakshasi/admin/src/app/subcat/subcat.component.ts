import { Component, OnInit, Inject } from '@angular/core';
import {Http} from '@angular/http';

@Component({
  selector: 'app-subcat',
  templateUrl: './subcat.component.html',
  styleUrls: ['./subcat.component.css']
})
export class SubcatComponent implements OnInit {
  cat_data;txtsubcat;drpcat;gdata;

  constructor(@Inject(Http) private obj) { }

  funcget()
  {
    this.obj.get("subcatserverfile/cget").subscribe(
      dt2=>{
         this.cat_data=JSON.parse(dt2._body)
      }
    )
  }

  fun_ins_subcat(){
    var ob={subname:this.txtsubcat,catid:this.drpcat}

  this.obj.post("subcatserverfile/ins_sub",ob).subscribe(
    dt1=>{
     alert(dt1._body)
     this.funsubget()
    }
  )

  }
  funsubget(){
    this.obj.get("subcatserverfile/subget").subscribe(
      dt1=>{
            this.gdata=JSON.parse(dt1._body)
            
      }
    )
  }

  funupdate(){

    
  }

  funinactive(obj)
      {
        this.obj.post("subcatserverfile/inactive",obj).subscribe()
        this.funsubget()
      }

      funactive(obj)
      {
         this.obj.post("subcatserverfile/active",obj).subscribe()
         this.funsubget()
      }


  
  ngOnInit ( ) {
    this.funcget()
    this.funsubget()


  }


}









 

/*
txtsubcat;drpcat;allsubcat



  constructor( @Inject(Http) private obj) { }
  
  fun_ins_subcat(){
    
    var dataobj={subcatname:this.txtsubcat,catid:this.drpcat}
    this.obj.post("subcat_file_ref/ins_sub_cat",dataobj).subscribe(this.cback2)
  }
  cback2=(dtt)=>{
    alert(dtt._body)
    this.fun_get_subcat()
  }

 fun_get_subcat(){
   this.obj.get("subcat_file_ref/get_subcat").subscribe(this.cback4)
 }
 cback4=(sub)=>{
   this.allsubcat=JSON.parse(sub._body)
 }

  cat_data;
  ngOnInit ( ) {
    this.obj.get("cat_file_ref/get_cat").subscribe(this.cback3)
    
  }
  cback3=(dt)=>{
  this.cat_data=JSON.parse(dt._body)
  this.fun_get_subcat()
  }
  
   }

*/
