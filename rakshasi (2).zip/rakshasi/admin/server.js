exp=require("express")
fup=require("express-fileupload")
mj=require("mongojs")
conn=mj("mongodb://localhost:27017/raji")
bp=require("body-parser")
app=exp()
app.use(bp.json())
app.use(fup())


cat_ref = require("./myfiles/cat_serverfiles")
subcat_ref = require("./myfiles/subcat_serverfiles")
subsubcat_ref=require("./myfiles/subsubcat")
brand_ref=require("./myfiles/brandserverfile")
product_ref=require("./myfiles/product_serverfiles")

app.post("/upload",function(req,res){
    iname=req.files.f1.name
    iref=req.files.f1
    var dt=new Date()
    dt=dt/1000
    iname="img"+parseInt(dt)+"_"+iname
    iref.mv("./src/assets/uploads/"+iname)
    res.redirect("http://localhost:1200/products?res="+iname)
})

app.use("/catserverfile", cat_ref)
app.use("/subcatserverfile", subcat_ref)
app.use("/subsubcatfile",subsubcat_ref)
app.use("/brandserverfile",brand_ref)
app.use("/productserverfile",product_ref)

app.listen(8457)
console.log("running through 8457")


/*
*/