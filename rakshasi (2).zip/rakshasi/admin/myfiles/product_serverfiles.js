exp=require("express")
rout=exp.Router();

mj=require("mongojs")
conn=mj("mongodb://localhost:27017/raji")

rout.get("/cget",function(req,res){
conn.tbl_cat.find(function(err,result){
   // console.log(result)
    res.send(result)
})


rout.get("/sget",function(req,res){
conn.tbl_subcat.find(function(err,result){
    res.send(result)
})

})

rout.post("/insert_img",function(req,res){
    img=req.body
    console.log(img)
    conn.tbl_products.find().sort({_id:-1}).limit(1,function(err,result){
        id=result[0]._id
        console.log(id)
        conn.tbl_products.update({_id:id},{$set:{pimage:img.image}})
        res.send("img updated")
    })
})

rout.get("/sscat_get",function(req,res){
    //console.log("hi")
    conn.tbl_subsubcat.find(function(err,result){
        res.send(result)
       // console.log(result)
    })
})


rout.get("/brand_get",function(req,res){
    //console.log("hi")
    conn.tbl_brand.find(function(err,result){
        res.send(result)
       // console.log(result)
    })
})

rout.post("/ins_product",function(req,res){
    ob=req.body
    conn.tbl_products.find().sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0){
            iid=1;
        }else {
            iid=result[0]._id;
            iid++;
        }
        conn.tbl_products.insert({_id:iid,catid:ob.catname,scat:ob.subcat,sscat:ob.subsubcat,brandname:ob.brandname,pcolour:ob.pcolour,pquantity:ob.pquantity,prating:ob.prating})
        
    })

    res.send("inserted")
})






})
module.exports=rout;