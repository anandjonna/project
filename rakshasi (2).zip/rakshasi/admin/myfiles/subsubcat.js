exp=require("express")
rout=exp.Router();

mj=require("mongojs")
conn=mj("mongodb://localhost:27017/raji")

rout.get("/cget",function(req,res){
conn.tbl_cat.find(function(err,result){
   // console.log(result)
    res.send(result)
})

})


rout.post("/subget",function(req,res){
    ob=req.body
    conn.tbl_subcat.find(ob,function(err,result){
        console.log(result)
        res.send(result)
    })
    
    })
    
rout.post("/insert",function(req,res){
    ob=req.body
    conn.tbl_subsubcat.find().sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0){
            iid=1;
        }else {
            iid=result[0]._id;
            iid++;
        }
        conn.tbl_subsubcat.insert({_id:iid,catid:ob.catname,scat:ob.subcat,sscat:ob.subsubcat})
        
    })

    res.send("inserted")
})


rout.get("/sscat",function(req,res){
    conn.tbl_subsubcat.find(function(err,ssc_result){
        conn.tbl_subcat.find(function(err,sc_result){
            conn.tbl_cat.find(function(err,c_result){
                arr=[];
                for(i=0;i<ssc_result.length;i++){
                    ob={};
                    ob=ssc_result[i]
                    for(j=0;j<sc_result.length;j++){
                    if(ssc_result[i].scat==sc_result[j]._id){
                        ob.scname=sc_result[j].subcatname;
                    }
                  }
                  for(k=0;k<c_result.length;k++){
                      if(c_result[k]._id==ssc_result[i].catid){
                        ob.catname=c_result[k].catname;
                      }
                  }
                  arr.push(ob);
                }
                res.send(arr)
            })
        })
    })
})
module.exports=rout;