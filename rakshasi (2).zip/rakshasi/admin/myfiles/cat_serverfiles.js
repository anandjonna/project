exp=require("express")
rt=exp.Router()

mj=require("mongojs")
conn=mj("mongodb://localhost:27017/raji")

rt.post("/ins_cat", function(req,res){   
    ob=req.body
    conn.tbl_cat.find().sort({_id:-1}).limit(1, function(err, reslt){

        if(reslt.length==0)
        iid=1
        else{
            iid=(reslt[0]._id)
            iid++
        }
        //console.log(iid)
        conn.tbl_cat.insert({_id:iid, catname:ob.catname,active:1})
        res.send("Category inserted")
    })
})

rt.get("/get_cat", function(err, ress){
    conn.tbl_cat.find(function(err, reslt){
        ress.send(reslt)
    
    })
})

rt.post("/save", function(req,res){
    savedata=req.body
    //console.log(savedata)
    conn.tbl_cat.update(savedata[0],savedata[1])
    res.send("updated")
    })
    
rt.post("/catinactive",function(req,res){
        reqdata=req.body
        iid=reqdata._id
        conn.tbl_cat.update({_id:iid},{$set:{active:0}},function(err,result){
        res.send(result)
        })
            
        })
    
rt.post("/catactive",function(req,res){
            reqdata=req.body
            iid=reqdata._id
            conn.tbl_cat.update({_id:iid},{$set:{active:1}},function(err,result){
                res.send(result)
            })
                
            })

 
module.exports=rt;

/*


*/
