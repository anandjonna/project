exp=require("express")
rt=exp.Router()

mj=require("mongojs")
conn=mj("mongodb://localhost:27017/raji")


rt.get("/cget", function(req,res){
    conn.tbl_cat.find(function(err,result)
   {
       res.send(result)
   })
}) 


rt.post("/ins_sub",function(req,res)
{
reqdata=req.body
conn.tbl_subcat.find().sort({_id:-1}).limit(1,function(err,result)
{
    if(result.length==0)
    {
        iid1=1
    }
    else
    {
        iid1=result[0]._id
        iid1++
       
    }
    insdata={_id:iid1,subcatname:reqdata.subname,cid:reqdata.catid,active:1}
    conn.tbl_subcat.insert(insdata)
    res.send("inserted")
})

})
rt.get("/subget", function(req,res){
    conn.tbl_subcat.find(function(err,subresult)
   {
       conn.tbl_cat.find(function(error,catresult)
       {
       var arr=[]
       for(var i=0;i<subresult.length;i++)
       {
           for(var j=0;j<catresult.length;j++)
           {
               if(subresult[i].cid==catresult[j]._id)
               {
                           obj=subresult[i]
                           obj.catname=catresult[j].catname
                           arr.push(obj)
                           console.log(obj)
               }
           }
       }
       res.send(arr)   
       
       })
   })
  
})

rt.post("/inactive",function(req,res){
    inactive=req.body
    conn.tbl_subcat.update({_id:inactive._id},{$set:{active:0}},function(err,result)
 {
    res.send(result)
})
})

rt.post("/active",function(req,res){
    active=req.body
    conn.tbl_subcat.update({_id:active._id},{$set:{active:1}},function(err,result){
        res.send(result)
    })
})
rt.post("/update",function(req,res){
    updata=req.body
     this.oldob={_id:this.tmp,cid:this.cattext,subcatname:this.subtext}     
     conn.tbl_subcat.update(updata[0],updata[1])
    res.send("updated");
})




module.exports=rt













/*

rt.post("/ins_sub_cat",function(req,res){
    ob=req.body
    conn.tbl_subcat.find().sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0)
        iid=1
        else
        {
        iid=(result[0]._id)
        iid++
        }
        console.log(iid)
        conn.tbl_subcat.insert({_id:iid,subcatname:ob.subcatname,catid:ob.catid})
        res.send("inserted")
    })
})

*/