var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router()
rout.post("/product_get",function(req,res){
    ob=req.body
    console.log(ob)
conn.product.find({subsubcatid:ob.subsubcatid},function(err,result){
    res.send(result)
})
})
module.exports=rout