var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router()
rout.get("/subcat_get",function(req,res){
conn.subcat_ins.find(function(err,result){
    res.send(result)
})
})
module.exports=rout