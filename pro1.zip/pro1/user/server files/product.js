var exp= require("express");
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router()
rout.post("/getproduct",function(req,res){
    obj=req.body
    console.log(obj)
conn.prodcut.find({subsubcatid:1},function(err,result){
    res.send(result)
})
})
module.exports=rout;