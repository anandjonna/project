import { Component,Inject,OnInit } from '@angular/core';
import { Http } from "@angular/http"
import {trigger,animate,state,style,transition} from "@angular/animations";

var myanimations=[trigger("anm1",
[state("st1",style({top:'100px'})),
state("st2",style({top:'-700px'})),
transition("*=>*",animate("1000ms"))]
)]

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations:[myanimations]
})
export class AppComponent {
  title = 'app';
  cdata;sdata;ssdata;tmp="st2";change=1;

  login_fun(){
    this.tmp='st1';
    this.change=1;
  }
constructor(@Inject(Http) public obj){}
ngOnInit(){
  this.obj.get("cat_ref/cat_get").subscribe(
      dt=>{
        this.cdata=JSON.parse(dt._body)
        
      })

  this.obj.get("subcat_ref/subcat_get").subscribe(
    dt=>{
      this.sdata=JSON.parse(dt._body)
     
    })

    this.obj.get("subsubcat_ref/subsubcat_get").subscribe(
      dt=>{
        this.ssdata=JSON.parse(dt._body)
      })

  }
}
