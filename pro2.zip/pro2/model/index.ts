import { Component,NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";

@Component({selector:"s1",template:"<h1>hi this anand jonna</h1>"})
class cls1{}

@NgModule({
    declarations:[cls1],
    imports:[BrowserModule],
    bootstrap:[cls1]
})
class clsmod{}
platformBrowserDynamic().bootstrapModule(clsmod)