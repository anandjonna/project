import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms"

import { AppComponent } from './app.component';
import { CatComponent } from './cat/cat.component';
import { SubcatComponent } from './subcat/subcat.component';
import { SubsubcatComponent } from './subsubcat/subsubcat.component';
import { BrandComponent } from './brand/brand.component';
import { ProductComponent } from './product/product.component';
import  {RouterModule} from '@angular/router';
import {HttpModule} from "@angular/http"

var obj=[{
  path:"",component:AppComponent
},{
  path:"cat",component:CatComponent
},{
  path:"subcat",component:SubcatComponent
},{
  path:"subsubcat",component:SubsubcatComponent
},{
  path:"brand",component:BrandComponent
},{
  path:"product",component:ProductComponent
}]
var rout=RouterModule.forRoot(obj)

@NgModule({
  declarations: [
    AppComponent,
    CatComponent,
    SubcatComponent,
    SubsubcatComponent,
    BrandComponent,
    ProductComponent
  ],
  imports: [
    BrowserModule,rout,HttpModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
