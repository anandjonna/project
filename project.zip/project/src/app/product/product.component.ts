import { Component, OnInit,Inject } from '@angular/core';
import {Http} from "@angular/http"

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor( @Inject(Http) public obj) { }
catdetails;sdata;catsel;subcatsel;sscatdet;
brrec;pntxt;pctxt;pqtxt;pptxt;pdtxt;prtxt;
subsubcatsel;brandsel;
//product Insert
prod_ins(){
alert(this.catsel)
alert(this.subcatsel)
alert(this.subsubcatsel)
alert(this.brandsel)
alert(this.pntxt)
alert(this.pctxt)
alert(this.pqtxt)
alert(this.pdtxt)
alert(this.pptxt)
alert(this.prtxt)

}


//To get Category details
getcat(){
  this.obj.get("fi1/met2").subscribe(
    dtt=>{
      this.catsel=1
      this.catdetails=JSON.parse(dtt._body)
      
    })
}
// To get the subcategory names based on catergory name
get_subcat_cat(){
    
  var csel={cid:this.catsel}
  this.obj.post("fi2/getsub",csel).subscribe(
    dtt=>{
      this.sdata=JSON.parse(dtt._body)
    
    })
}
//To get subsubcategory name based on subcategory
get_subsubcat_subcat(){
 var ssel={subcatid:this.subcatsel}
 this.obj.post("fi3/subsubdet",ssel).subscribe(
   sscdet=>{
          this.sscatdet=JSON.parse(sscdet._body)
   })
}

//To get brand details
fun_brand_get(){
  this.obj.get("fi4/get_brand").subscribe(
    gb=>{
      this.brrec=JSON.parse(gb._body)
    })
}
  
  ngOnInit() {
    this.getcat()
    this.fun_brand_get()
  }

}
