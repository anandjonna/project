import { Component, OnInit,Inject } from '@angular/core';
import { getPluralCategory } from '@angular/common/src/i18n/localization';
import {Http} from "@angular/http"
@Component({
  selector: 'app-subsubcat',
  templateUrl: './subsubcat.component.html',
  styleUrls: ['./subsubcat.component.css']
})
export class SubsubcatComponent implements OnInit {
cdata;
catsel;ssdt;
subsel;subsubtxt
sdata;ssdata;tmp=0;oldob;newob;
upcs;upscs;upstv;scdata;
  constructor(@Inject(Http) public obj) { }
  //sub sub category  insertion
  ssubins(){
    var ob={catid:this.catsel,scatid:this.subsel,ssubcatname:this.subsubtxt}
    this.obj.post("fi3/subsubins",ob).subscribe(
      dttt=>{
        alert(dttt._body)
        this.ssubget()
        this.catsel=""
        this.subsel=""
        this.subsubtxt=""
      })
  }

  funsave(){
    this.newob={catid:this.upcs,subcatid:this.upscs,subsubname:this.upstv}
      var arr=[this.oldob,this.newob]
    this.obj.post("fi3/subsubsave",arr).subscribe(
      svdt=>{
        alert(svdt._body)
        this.tmp=0;
        this.ssubget()
      })
  }

  //getting subsubcat table records
  ssubget(){
    this.obj.get("fi3/getssub").subscribe(      
      ssd=>{
        this.ssdata=JSON.parse(ssd._body)
        
      }
    )
  }
  catid;subcatid;
  funupdt(sst){
    this.tmp=sst._id
    this.catid=sst.catid;
    this.upstv=sst.subsubname;
    this.catsel=this.catid;
   this.catdrp()
    this.subsel=sst.subcatid
  }

  //===============active, inactive buttons=============

fun_inactive(x,inact){
  x.active=0
  var ob={_id:x._id,active:inact}
  this.obj.post("fi3/inactive",ob).subscribe(
    di=>{
      alert(di._body)
    })
  }
  fun_active(y,act){
    y.active=1
    var ob={_id:y._id,active:act}
    this.obj.post("fi3/active",ob).subscribe(
      di=>{
        alert(di._body)
      })
  }


  getcat(){
  this.obj.get("fi1/met2").subscribe(
    dt=>{
      this.cdata=JSON.parse(dt._body)
    })
  }
  catdrp(){
    
    var csel={cid:this.catsel}
    this.obj.post("fi2/getsub",csel).subscribe(
      dtt=>{
        this.sdata=JSON.parse(dtt._body)
      
      })
  }
  
  ctdrp(){
    var csel={cid:this.upcs}
    this.obj.post("fi2/getsub",csel).subscribe(
      dtt=>{
        this.scdata=JSON.parse(dtt._body)
      })
  }

  ngOnInit() {
    this.getcat()
    this.ssubget()
  }

}

