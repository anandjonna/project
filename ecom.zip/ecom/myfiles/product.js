var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router()
rout.post("/product_ins",function(req,res){
    obj=req.body
    conn.product.find().sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0){
            iid=1
        }
        else{
            iid=result[0]._id
            iid++
        }
        obj1={_id:iid,catid:obj.catid,subcatid:obj.subcatid,subsubcatid:obj.subsubcatid,brandid:obj.brandid,
        productname:obj.pname,pquantity:obj.pquantity,pdesc:obj.pdesc,pprice:obj.pprice,prating:obj.prating,pcolor:obj.pctxt}
        console.log(obj1.pcolor)
        conn.product.insert(obj1)
        res.send("inserted successfully")
    })
    //console.log(obj)
    //conn.product.insert(obj)
})

rout.post("/upimg",function(req,res){
    ob=req.body
    conn.product.find().sort({_id:-1}).limit(1,function(err,result){
        id=result[0]._id
        conn.product.update({_id:id},{$set:{pimg:ob.image}})
    })
    
})

module.exports=rout;