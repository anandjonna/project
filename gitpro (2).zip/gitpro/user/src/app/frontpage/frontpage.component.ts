import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import {Http} from "@angular/http"
@Component({
  selector: 'app-product',
  templateUrl: './frontpage.component.html',
  styleUrls: ['./frontpage.component.css']
})
export class FrontpageComponent implements OnInit {
subsubid;pdata;pno=1;
  constructor(@Inject(ActivatedRoute) public obj,@Inject(Http) private ht) { }

  ngOnInit() {
    this.obj.params.subscribe(x=>{
      this.subsubid=x["_id"]
      var ob={subsubcatid:this.subsubid}
      this.ht.post("front_ref/product_get",ob).subscribe(dt=>{
        this.pdata=JSON.parse(dt._body)
      alert(dt._body)
      })
    })
  }

}
