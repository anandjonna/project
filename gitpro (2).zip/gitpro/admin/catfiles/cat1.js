var exp=require("express")
var mj=require("mongojs")
rout=exp.Router()
conn=mj("mongodb://localhost:27017/cat")
rout.post("/met1",function(req,res){
ob=req.body
var id=conn.tbl_cat.find().sort({_id:-1}).limit(1,function(err,result){
  iid=(result.length)
  console.log(iid)
    /* iid=(result[0]._id)
   iid++
    uid={_id:iid,uname:ob.uname}
    conn.tbl_cat.insert(uid)
    res.send("inserted successfully"+uid)    */
}
)
})
module.exports=rout