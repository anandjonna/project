import { Component,Inject,OnInit } from '@angular/core';
import { Http } from "@angular/http"
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  cdata;sdata;ssdata;
constructor(@Inject(Http) public obj){}
ngOnInit(){
  this.obj.get("cat_ref/cat_get").subscribe(
      dt=>{
        this.cdata=JSON.parse(dt._body)
        alert(this.cdata)
      })

  this.obj.get("subcat_ref/subcat_get").subscribe(
    dt=>{
      this.sdata=JSON.parse(dt._body)
      alert(this.sdata)
    })

    this.obj.get("subsubcat_ref/subcat_get").subscribe(
      dt=>{
        this.ssdata=JSON.parse(dt._body)
       alert(this.ssdata)
      })

  }
}
