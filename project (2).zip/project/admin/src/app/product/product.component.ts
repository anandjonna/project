import { Component, OnInit,Inject } from '@angular/core';
import {Http} from "@angular/http"

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor( @Inject(Http) public obj) { }
catdetails;sdata;catsel;subcatsel;sscatdet;
brrec;pntxt;pctxt;pqtxt;pptxt;pdtxt;prtxt;
subsubcatsel;brandsel;img;ob;pdata;
//product Insert
prod_ins(){
alert(this.catsel)
alert(this.subcatsel)
alert(this.subsubcatsel)
alert(this.brandsel)
alert(this.pntxt)
alert(this.pctxt)
alert(this.pqtxt)
alert(this.pdtxt)
alert(this.pptxt)
alert(this.prtxt)


}

get_product(){
  this.obj.get("fi5/get_product").subscribe(
    gpd=>{
        this.pdata=JSON.parse(gpd._body)
    })
}



//To get Category details
getcat(){
  this.obj.get("fi1/met2").subscribe(
    dtt=>{
      this.catdetails=JSON.parse(dtt._body)

    })
}
// To get the subcategory names based on catergory name
get_subcat_cat(){

  var csel={cid:this.catsel}
  this.obj.post("fi2/getsub",csel).subscribe(
    dtt=>{
      this.sdata=JSON.parse(dtt._body)

    })
}
// To insert product
  fun_ins(){
      this.ob={catid:this.catsel,subcatid:this.subcatsel,subsubcatid:this.subsubcatsel,brandid:this.brandsel,pname:this.pntxt
      ,pquantity:this.pqtxt,pdesc:this.pdtxt,pprice:this.pptxt,prating:this.prtxt,pcolor:this.pctxt}
    this.obj.post("fi5/product_ins",this.ob).subscribe(
      pd=>{
          alert(pd._body)
         
          
      })
      var form_ref=<HTMLFormElement>document.getElementById("fm1")
      form_ref.submit()
}

//To get subsubcategory name based on subcategory
get_subsubcat_subcat(){
 var ssel={subcatid:this.subcatsel}
 this.obj.post("fi3/subsubdet",ssel).subscribe(
   sscdet=>{
          this.sscatdet=JSON.parse(sscdet._body)
   })
}

//To get brand details
fun_brand_get(){
  this.obj.get("fi4/get_brand").subscribe(
    gb=>{
      this.brrec=JSON.parse(gb._body)
    })
}

  ngOnInit() {
    this.getcat()
    this.fun_brand_get()
    this.get_product()
    
    var arr=document.URL.split("?")
    if(arr.length>1){
      var iname=arr[1].split("=")
      if(iname[0]=="res"){
         this.img=iname[1]
        var ob={image:this.img}
        this.obj.post("fi5/upimg",ob).subscribe(
          pi=>{
            alert(pi._body)
            this.get_product()
          })
      }
    }
  }

}
