var exp=require("express")
var fup=require("express-fileupload")
var bp= require("body-parser")
f1=require("./myfiles/catfile")
f2=require("./myfiles/subcatfile")
f3=require("./myfiles/subsubcatfile")
f4=require("./myfiles/brand")
f5=require("./myfiles/product")
app = exp()
app.use(fup())
app.use(bp.json())

app.use("/fi1",f1)
app.use("/fi2",f2)
app.use("/fi3",f3)
app.use("/fi4",f4)
app.use("/fi5",f5)

app.post("/uploads",function(req,res){
  iname=req.files.f1.name
  iref=req.files.f1
  var dt = new Date()
  dt=dt/1000
  iname=("img"+parseInt(dt)+"_"+iname)
  iref.mv("../src/assets/uploads/"+iname)
  res.redirect("http://localhost:4101/product?res="+iname)
  
  
})
app.listen(5100)
console.log("server started with port no.5100")
