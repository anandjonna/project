import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import {Http} from "@angular/http"
import {ViewcartService} from "../viewcart.service"

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
subsubid;newproduct;runproduct;prodid;
  constructor(@Inject(Http) public obj,@Inject(ActivatedRoute) public ar,public cartt:ViewcartService) { }

  arr:any=[];
  parr:any=[]
  localdata;
  len
 funaddcart(product){
   this.arr=[]
   this.parr=[]

 alert(product._id)
 this.localdata= JSON.parse(localStorage.getItem("cart"))
 
 if(this.localdata!=null){
   for(var i=0;i<this.localdata.length;i++){
     if(this.localdata[i]._id==product._id){
      
      var prevqty=this.localdata[i].selqty;
      var newqty=1; 
      var totqty=prevqty+newqty
      
      this.localdata[i].selqty=totqty
      localStorage.setItem("cart",JSON.stringify(this.localdata))
      this.cartt.funcartobserve(this.localdata.length.toString())
     }
     else{
     this.parr.push(this.localdata[i])
     this.len=this.localdata.length
     alert(this.len)
    if(this.localdata[i]._id==this.localdata[this.len - 1]._id){
        product.selqty=1
        this.parr.push(product)
       localStorage.setItem("cart",JSON.stringify(this.parr))
       this.cartt.funcartobserve(this.parr.length.toString())
      }
     }
   }
   
 }
 else{
 product.selqty=1
 alert(product.selqty)
 this.arr.push(product)
 localStorage.setItem("cart",JSON.stringify(this.arr))
 this.cartt.funcartobserve(this.arr.length.toString())
 alert(localStorage.getItem("cart"))
 }
  }
 

  ngOnInit() {
   this.obj.get("product_ref/getnew_product").subscribe(x=>{
     this.newproduct=JSON.parse(x._body)
     
   })
   this.obj.get("product_ref/getrun_product").subscribe(x=>{
    this.runproduct=JSON.parse(x._body)
    
  })
  this.ar.params.subscribe(x=>{
    this.prodid=x["_id"]
  })
  }

}
