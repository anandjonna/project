import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import {Http} from "@angular/http"
import {ViewcartService} from "../viewcart.service"
@Component({
  selector: 'app-more',
  templateUrl: './more.component.html',
  styleUrls: ['./more.component.css']
})
export class MoreComponent implements OnInit {
moredata;qtytxt=1;halfstar=0;
  constructor( @Inject(ActivatedRoute) public ar,@Inject(Http) public ht,public cartt:ViewcartService) { 
//localStorage.removeItem("cart")
  }

 arr:any=[];
 parr:any=[]
 localdata;
 len
funaddcart(product){
  this.arr=[]
  this.parr=[]
//   var arr=[];var newarr=[]
  
// this.localdata=JSON.parse(localStorage.getItem("cart"))
// if(this.localdata!=null){
//   arr=JSON.parse(localStorage.getItem("cart"))
//   product.selqty=this.qtytxt
//   var str='\\"_id\\":'+product._id+",";
//   alert(str)
//   if(localStorage.getItem('cart').indexOf(str)){
//     for(var i=0;i<arr.length;i++){
//       var str1=JSON.parse(arr[i])
//       if(str1._id==product._id){
//         str1.selqty=product.selqty
//         alert("updated product")
//       }
//       else{
//         newarr.push(JSON.stringify(str1))
//       }
//     }
//   }
//   newarr.push(JSON.stringify(product));
//   this.cartt.funcartobserve(newarr.length.toString())

//   // for(var i=0;i<this.localdata.length;i++){
//   //   if(this.localdata[i].id==obj.id){
//   //     this.localdata[i].qty++
     
//   //   }
//     //  else{
//     //   this.localdata.push(obj)
//     //  }
//     //  localStorage.setItem("cart",JSON.stringify(this.localdata))
//     //   }
   
// }
// else{
//   product.selqty=this.qtytxt
//   newarr.push(JSON.stringify(product))
//   this.cartt.funcartobserve(newarr.length.toString())
// }
// localStorage.setItem("cart",JSON.stringify(newarr))

// // else{
// //   var fob=[{id:prodid,qty:1}]
// //   localStorage.setItem("cart",JSON.stringify(fob))
// // }
alert(product._id)
this.localdata= JSON.parse(localStorage.getItem("cart"))

if(this.localdata!=null){
  for(var i=0;i<this.localdata.length;i++){
    if(this.localdata[i]._id==product._id){
     
     var prevqty=this.localdata[i].selqty;
     var newqty=this.qtytxt; 
     var totqty=prevqty+newqty
     
     this.localdata[i].selqty=totqty
     localStorage.setItem("cart",JSON.stringify(this.localdata))
     this.cartt.funcartobserve(this.localdata.length.toString())
    }
    else{
    this.parr.push(this.localdata[i])
    this.len=this.localdata.length
    alert(this.len)
   if(this.localdata[i]._id==this.localdata[this.len - 1]._id){
       product.selqty=this.qtytxt
       this.parr.push(product)
      localStorage.setItem("cart",JSON.stringify(this.parr))
      this.cartt.funcartobserve(this.parr.length.toString())
     }
    }
  }
  
}
else{
product.selqty=this.qtytxt
alert(product.selqty)
this.arr.push(product)
localStorage.setItem("cart",JSON.stringify(this.arr))
this.cartt.funcartobserve(this.arr.length.toString())
alert(localStorage.getItem("cart"))
}
 }












fun_inc(qty){
 
  if(this.qtytxt<qty)
  this.qtytxt++;
 else
 alert("exceeded")
}
fun_dec(){
  if(this.qtytxt>1)
  this.qtytxt--;
  else
  alert("quantity should not be lessthan 1")
}
ratearr=[];cartlength;cartitemlength
  ngOnInit() {
    if(localStorage.getItem("cart")!=null){
    this.cartlength=JSON.parse(localStorage.getItem("cart"))
    this.cartt.funcartobserve(this.cartlength.length.toString());
   
  }


    this.ar.params.subscribe(x=>{
      var prodid=parseInt(x["id"])
      var ob={_id:prodid}
      var product=localStorage.getItem("cart")
        
        this.ht.post("product_ref/get_more",ob).subscribe(x=>{
          this.moredata=JSON.parse(x._body)
         var rating=(this.moredata[0].prating)
         this.ratearr=[]
          for(var i=1;i<=rating;i++){
              this.ratearr.push(i)
          }
          i--;
          if(rating>i){
            this.halfstar=1
          }
         
        })
    })
  }

}
