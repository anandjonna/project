import { Component, OnInit,Inject } from '@angular/core';
import {Router} from "@angular/router";
import {Http} from "@angular/http";
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
change=0;cartarr=[];userorders;user;trackid;status;
  constructor(@Inject(Router) public rt,@Inject(Http) public ht) { }
  funOrders(){
    this.change=1;
    this.userorders=JSON.parse(localStorage.getItem("userOrders"))
  }
  funWishlist(){
    this.change=2;
  }
  funCartList(){
    this.change=3;
    this.cartarr=JSON.parse(localStorage.getItem("cart"))
    
  }
  funAccount(){
    this.change=4;
  }
  funtrack(){
    this.change=5;
  }
  funusertrack(){
    alert(this.trackid)
    var obj={tid:this.trackid}
    this.ht.post("userorders/track",obj).subscribe(dt=>{
      var stat=JSON.parse(dt._body)
      this.status=stat[0].orderstatus;
      alert(this.status)
    })
  }
  ngOnInit() {
    if(localStorage.getItem("uname")==null){
      this.rt.navigateByUrl("/")

    
     
    }
    this.user=(localStorage.getItem("uid"))
   
  }

}
