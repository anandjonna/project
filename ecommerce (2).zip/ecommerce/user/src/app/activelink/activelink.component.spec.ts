import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivelinkComponent } from './activelink.component';

describe('ActivelinkComponent', () => {
  let component: ActivelinkComponent;
  let fixture: ComponentFixture<ActivelinkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivelinkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivelinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
