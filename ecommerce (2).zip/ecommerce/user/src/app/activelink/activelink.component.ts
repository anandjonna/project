import { Component, OnInit, Inject } from '@angular/core';
import {Http} from "@angular/http"

@Component({
  selector: 'app-activelink',
  templateUrl: './activelink.component.html',
  styleUrls: ['./activelink.component.css']
})
export class ActivelinkComponent implements OnInit {

  constructor(@Inject(Http) public ht) { }

  ngOnInit() {
    var aurl=document.URL.split("?")
    var aa=aurl[1].split("=")
    var alink={activation:aa[1]}
    this.ht.post("reg_ref/activelink",alink).subscribe(link=>{
      alert(link._body)
    })

  }

}
