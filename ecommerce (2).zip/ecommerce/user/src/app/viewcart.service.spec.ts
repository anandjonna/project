import { TestBed, inject } from '@angular/core/testing';

import { ViewcartService } from './viewcart.service';

describe('ViewcartService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewcartService]
    });
  });

  it('should be created', inject([ViewcartService], (service: ViewcartService) => {
    expect(service).toBeTruthy();
  }));
});
