import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import {Http} from "@angular/http"
import {ViewcartService} from "../viewcart.service";
declare var $:any;

@Component({
  selector: 'app-product',
  templateUrl: './frontpage.component.html',
  styleUrls: ['./frontpage.component.css']
})
export class FrontpageComponent implements OnInit {
subsubid;pdata;pno=1;filterbrand:any={productname:""}
  constructor(@Inject(ActivatedRoute) public obj,@Inject(Http) private ht) { }



range;
funsort(){
  alert(this.range)
}
  ngOnInit() {
    
      $("#demo").slider({
      
        max:70000,
        min:15000,
        range:true,
        slide:  (e,ui)=>{
          //alert(ui)
          $('#d').html("value is "+ui.values[0])
          $('#d1').html("value is"+ui.values[1])
          var minvalue=ui.values[0]
           var maxvalue=ui.values[1]
           this.range={min:minvalue,max:maxvalue,ssubid:this.subsubid}
           this.ht.post("product_ref/productsort",this.range).subscribe(dt=>{
             this.pdata=JSON.parse(dt._body)
           }
           )
           
        }
      })
    
   
    this.obj.params.subscribe(x=>{
      this.subsubid=x["_id"]
      var ob={subsubcatid:this.subsubid}
      this.ht.post("front_ref/product_get",ob).subscribe(dt=>{
        this.pdata=JSON.parse(dt._body)
      })
    })
  }

}
