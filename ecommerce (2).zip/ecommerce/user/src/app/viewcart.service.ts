import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ViewcartService {
 private initialItem=new BehaviorSubject("0")
 currentItem=this.initialItem.asObservable()
  constructor() { }
  funcartobserve(items:string){
    this.initialItem.next(items)
  }
}
