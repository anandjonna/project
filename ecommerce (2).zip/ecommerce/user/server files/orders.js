exp=require("express");
nodemailer=require("nodemailer")

rout=exp.Router()

rout.post("/track",function(req,res){
var id=req.body
console.log(id)
conn.userorders.find({_id:id.tid},function(err,result){
res.send( result)
})
})


rout.post("/getcartitems",function(req,res){
    var obj=req.body
    var arr=obj.products
    var uid=obj.userid
    console.log(arr)
    var products=[];
    for(var i=0;i<arr.length;i++){
        var obj={};
        obj.pid=arr[i]._id;
        obj.pname=arr[i].productname;
        obj.quantity=arr[i].selqty;
        obj.price=arr[i].pprice;
        obj.color=arr[i].pcolor;
        obj.image=arr[i].pimg;
        products.push(obj)
        
    }
    console.log(products)
    conn.userorders.find().sort({_id:-1}).limit(1,function(err,result){

        if(result==0){
            var id=1
        }
        else{
            id=result[0]._id
            id++
        }
        conn.userorders.insert({_id:id,userid:uid,dt:new Date(),products:products})
         
        res.send("inserted successfully")
       
        })
         conn.reg.find({uname:uid},function(err,result){
            mail=(result[0].email)
            console.log(mail)
        var mailobj=nodemailer.createTransport({
            service:'gmail',
            auth:{
                user:'anandjonna06@gmail.com',
                pass:'9908821643'
            }
        });
        mailobj.sendMail({
            from:'anandjonna06@gmail.com',
            to:mail,
            subject:"sending mail from anand cart",
            html:'<h1>Your payment done shortly you will receive your product</h1>'
        },function(err,res){    
            if(err){
                console.log(err);
            }else{
                console.log("Email sent:" + res.response)
            }
        })
    })
   
})
module.exports=rout;