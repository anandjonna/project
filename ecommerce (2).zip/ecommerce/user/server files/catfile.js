var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router()
rout.get("/cat_get",function(req,res){
conn.cat_ins.find(function(err,result){
    res.send(result)    
})
})
module.exports=rout