var exp=require("express")
rout=exp.Router()
var jwt=require("jsonwebtoken")
var sc=require("../server files/secret")
// rout.post("/login",function(req,res){
//     rdt=req.body
//     conn.reg.find(rdt).count(function(err,result){
//         res.send({count:result})
//         console.log(result.uname)
//     })
// })

rout.post("/login",function(req,res){
    rdt=req.body
    conn.reg.find(rdt,function(err,result){
        if(result.length==1){
            
            uname=result[0].uname
            console.log(uname)
            var tk=jwt.sign({id:uname},sc.secret)
            res.send({count:1,token:tk,uname:uname})
           sess=req.session
           sess.token=tk
           //console.log(sess.token) 
        }
        else{
            res.send({count:0})
        }
        
    })
})

rout.post("/validate_token",function(req,res){
    tk=req.body
    sstk=sess.token
    console.log(tk.utoken)
    console.log(sstk)
    if(tk.utoken==sstk){
        res.send({count:1})
    }else{
        res.send({count:0})
    }
 
})
rout.get("/sms",function(req,res){

res.redirect("http://www.onlinebulksmslogin.com/spanelv2/api.php?username=nalax&password=nalax@123&to=8297844903&from=TESTIN&message=hi%20your order placed")
})

rout.post("/changepwd",function(req,res){
    rqdt=req.body;
    conn.reg.update(rqdt[0],{$set:rqdt[1]})
    res.send("updated successfully")
})
module.exports=rout;