 exp=require("express")
 nodemailer=require("nodemailer")
rout=exp.Router();
rout.post("/activelink",function(req,res){
    al=req.body
    conn.reg.find(al,function(err,result){
        console.log(result)
        conn.reg.update(al,{$set:{activation:1}})
       
    })
})
rout.post("/Register",function(req,res){
    ob=req.body
    email=ob.email
    conn.reg.insert(ob)
    res.send("registration successful")
    conn.reg.find({email:email},function(err,result){
        act=result[0].activation;
        var rl="http://localhost:4200/active?res="+act
        var mailobj=nodemailer.createTransport({
            service:"gmail",
            auth:{
                user:'anandjonna06@gmail.com',
                pass:"9908821643"
            }
        })
        mailobj.sendMail({
            from:"anandjonna06@gmail.com",
            to:email,
            subject:"Click here to activate link",
            html:'<a href='+rl+'>Click</a>'
        },function(err,res){
            if(err)
            console.log(err)
            else
            console.log("Email Sent" +res.response)
        })
    })
   
})

module.exports=rout;