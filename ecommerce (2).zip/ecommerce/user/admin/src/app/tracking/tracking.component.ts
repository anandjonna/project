import { Component, OnInit } from '@angular/core';
import {Http} from "@angular/http"

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.css']
})
export class TrackingComponent implements OnInit {

  constructor( public ht:Http) { }
ord;

funupdate(oid,uid,os){
 
  var udet={_id:oid,userid:uid}
  var status={orderstatus:os}
  var arr=[udet,status];
  this.ht.post("userorders/orderstatus",arr).subscribe(ost=>{
    alert(ost._body)
  })

}
  ngOnInit() {
   this.ht.get("userorders/getuserorders").subscribe(dt=>{
     
     this.ord=JSON.parse(dt._body)
     alert(this.ord)
   }) 
  }

}
