exp=require("express")
rout.get("/getuserorders",function(req,res){
    conn.userorders.find(function(err,result){
        res.send(result)
    })
})
rout.post("/orderstatus",function(req,res){
    os=req.body
    console.log(os)
    conn.userorders.update(os[0],{$set:os[1]})
    res.send("updated successfully")
})
module.exports=rout;