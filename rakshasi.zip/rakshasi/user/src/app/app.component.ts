import { Component,Inject,OnInit } from '@angular/core';
import {Http} from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  data;sdata;ssdata;

  constructor(@Inject(Http) public obj ){}

  ngOnInit(){


// getting Category Menu///////////////
this.obj.get("catserver/user_cat").subscribe(
  dt=>{
    this.data=JSON.parse(dt._body)
    alert(this.data)
  })
 this.fun2()
}

// getting subcat in cat dropdown///////////
fun2(){
  this.obj.get("subcatserverfile/user_subcat").subscribe(
    dtt=>{
      this.sdata=JSON.parse(dtt._body)
      alert(this.sdata)
    })
}
}
///////////getting subsubcategory///////////
/* this.obj.get("subsubcatserver/user_subsubcat").subscribe(
   dttt=>{
     this.ssdata=JSON.parse(dttt._body)
     alert(this.ssdata)
   }
 )

*/