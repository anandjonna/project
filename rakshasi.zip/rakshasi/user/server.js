exp=require("express")
app=exp()


cat_ref=require("./serverfiles/catserverfile")
subcat_ref=require("./serverfiles/subcatserverfile")
app.use("/catserver",cat_ref)
app.use("/subcatserverfile",subcat_ref)
app.listen(4594)
console.log("Excuted...server")