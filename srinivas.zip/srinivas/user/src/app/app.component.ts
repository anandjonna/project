import { Component,Inject,OnInit } from '@angular/core';
import { Http } from "@angular/http"
import {trigger,animate,state,style,transition} from "@angular/animations";

var myanimations=[trigger("anm1",
[state("st1",style({top:'100px'})),
state("st2",style({top:'-700px'})),
transition("*=>*",animate("1000ms"))]
)]

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations:[myanimations]
})
export class AppComponent {
  title = 'app';
  cdata;sdata;ssdata;tmp="st2";change=1;
  uname;pwd;rpwd;em;mbno;searchtxt;luname;lpwd;log_in_out=1;searchdata;sdrp=1;
  constructor(@Inject(Http) public obj){}
  fun_reg(){
    var ob={uname:this.uname,password:this.pwd,rpassword:this.rpwd,email:this.em,mobileno:this.mbno}
    alert(ob)
    this.obj.post("reg_ref/Register",ob).subscribe(
      x=>{
        alert(x._body)
      })
  }
  fun_search(){
    if(this.searchtxt.length==0){
      this.sdrp=0;
    }
    else{
      this.sdrp=1
   var ob={pname:this.searchtxt}
   this.obj.post("product_ref/get_product",ob).subscribe(x=>{
     this.searchdata=JSON.parse(x._body)
    
    })
  }
  }

  logout(){
    localStorage.removeItem("uname")
    this.log_in_out=1;
    this.tmp="st2"
  }

  login(){
var ob={uname:this.luname,password:this.lpwd}
this.obj.post("log_ref/login",ob).subscribe(
  x=>{
    var rst=JSON.parse(x._body)
    if(rst.count==0){
      alert("Invalid username/password")
    }
    else{
      localStorage.setItem("uname",this.luname)
      this.log_in_out=0;
    }
  }
)
  }


  login_fun(){
    this.tmp='st1';
    this.change=1;
  }

ngOnInit(){
  this.obj.get("cat_ref/cat_get").subscribe(
      dt=>{
        this.cdata=JSON.parse(dt._body)
        
      })

  this.obj.get("subcat_ref/subcat_get").subscribe(
    dt=>{
      this.sdata=JSON.parse(dt._body)
     
    })

    this.obj.get("subsubcat_ref/subsubcat_get").subscribe(
      dt=>{
        this.ssdata=JSON.parse(dt._body)
      })

  }
}
