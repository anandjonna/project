const express = require("express");

var ses = require("express-session")
const bodyparser = require("body-parser");
const register = require("./serverfiles/register")
const login = require("./serverfiles/login")
const complaint = require("./serverfiles/complaint")
const port = process.env.PORT || 3000;
const app = express();
app.use(bodyparser.json());
app.use(ses({secret:"something",saveUninitialized:true,resave:true,originalMaxAge:360000}))
app.use("/Register",register);
app.use("/login",login);
app.use("/Complaint",complaint);
app.listen(port,()=>{
    console.log(`server listening the port no ${port}`);
})