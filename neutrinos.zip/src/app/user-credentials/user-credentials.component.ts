import { Component, OnInit,Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Http } from '@angular/http';

@Component({
  selector: 'app-user-credentials',
  templateUrl: './user-credentials.component.html',
  styleUrls: ['./user-credentials.component.css']
})
export class UserCredentialsComponent implements OnInit {

  constructor( private router:Router,@Inject(Http) public http) { }

  userComplaints=0;
  showform=false;
  Description;
  Heading;
  complaint
  ngOnInit() {
    var Token = localStorage.getItem('usertoken')
    if(Token==null){
      this.router.navigateByUrl("/")
    }
    else{
      alert("else part")
      this.http.get("Login/tokenCompare").subscribe((data)=>{
        alert(data._body)
      })

      this.http.get("Complaint/getComplaints").subscribe((data)=>{
        this.complaint=JSON.parse(data._body)
      })
    }
    // if(this.userComplaints==0){
    //   alert("no complaints have been filed")

    // }


  }
  funFileComplaint(){
    this.showform=true;
    
  }
  funComplaintSubmit(){

    let complaint = {complaintHeading:this.Heading,complaintDescription:this.Description}
    this.http.post("Complaint/userComplaint",complaint).subscribe((comp)=>{
      alert(comp._body);
    })

    alert(this.Heading)
    alert(this.Description)
  }

}
