import { Component, OnInit,Inject } from '@angular/core';
import {Http} from '@angular/http'
import {Router} from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

 
  constructor( @Inject(Http) public http,private router:Router){ }
  title = 'app';
  show = true;
  hide = false; 
  remail;
  rpwd;
  rmobile;
  lemail;
  lpwd;
  isUser
  funLoginChange(){
   
    this.show=false;
    this.hide=true;
  }
  funRegisterChange(){
   
    this.show=true;
    this.hide=false; 
  }

  funLogin(){
   var userlogDetails={email:this.lemail,password:this.lpwd}
    this.http.post("Login/userLogin",userlogDetails).subscribe((dt)=>{
      this.isUser=JSON.parse(dt._body)
      if(this.isUser.login == "user"){
       
        localStorage.setItem("usertoken",this.isUser.token)
        this.router.navigateByUrl('/userDetails')
      }
      else{
        localStorage.setItem("agenttoken",this.isUser.token)
        this.router.navigateByUrl('/agentDetails')
      }
    })
    

  }
  funRegister(){

    var obj = {email:this.remail,password:this.rpwd,mobile:this.rmobile}
    alert(obj);
    this.http.post("Register/userRegister",obj).subscribe((dt)=>{
      alert(dt._body)
    })


  }

  ngOnInit() {
  }

}
