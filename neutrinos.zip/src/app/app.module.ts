import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { UserCredentialsComponent } from './user-credentials/user-credentials.component';
import { AgentDetailsComponent } from './agent-details/agent-details.component';
import { UserComponent } from './user/user.component';


var rout = [
  {path:"",component:UserComponent},
  {path:"userDetails",component:UserCredentialsComponent},
  {path:"agentDetails",component:AgentDetailsComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    UserCredentialsComponent,
    AgentDetailsComponent,
    UserComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(rout),FormsModule,HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
