import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-agent-details',
  templateUrl: './agent-details.component.html',
  styleUrls: ['./agent-details.component.css']
})
export class AgentDetailsComponent implements OnInit {

  constructor( private router:Router) { }

  ngOnInit() {
    if(localStorage.getItem('agenttoken')==null){
      this.router.navigateByUrl('/')
    }
  }

}
