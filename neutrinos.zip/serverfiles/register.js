const express = require("express");
const jwt = require("jsonwebtoken");
rout = express.Router();
const mj = require("mongojs")
 const conn=mj("mongodb://suman:sumanjc1992@ds127624.mlab.com:27624/neutrino")

rout.post("/userRegister",(req,res)=>{
    var user = req.body
    var useremail = user.email;
    conn.userDetails.find({email:useremail},(err,result)=>{
        if(result.length==0){
            console.log(user.password)
    token = jwt.sign({password:user.password},'secret')
    date = new Date();
    date = date.toLocaleDateString();
    userdetails={email:user.email,password:user.password,mobile:user.mobile,date:date,isAgent:false}
    conn.userDetails.save(userdetails)
    res.send("inserted successfully")
        }else{
            res.send("email already exist")
        }
       
    })
    
})

module.exports=rout;