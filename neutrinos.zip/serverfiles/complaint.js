const express = require("express");
const jwt = require("jsonwebtoken");

rout = express.Router();
const mj = require("mongojs")
 const conn=mj("mongodb://suman:sumanjc1992@ds127624.mlab.com:27624/neutrino")

 rout.post("/userComplaint",(req,res)=>{
     var obj = req.body
     var dt = new Date()
     var date = dt.toLocaleDateString()
     var comp = {complaintHeading:obj.complaintHeading,complaintDescription:obj.complaintDescription,date:date}
     conn.Complaint.save(comp,()=>{
         res.send("Complaint filed successfully");
     });
 })

 rout.get("/getComplaints",(req,res)=>{
    conn.Complaint.find({},(err,result)=>{
        if(err){
            res.send(err)
        }else{
            res.send(result)
        }
    })
 })

 module.exports=rout;