const express = require("express");
const jwt = require("jsonwebtoken");

rout = express.Router();
const mj = require("mongojs")
 const conn=mj("mongodb://suman:sumanjc1992@ds127624.mlab.com:27624/neutrino")






rout.post("/userLogin",(req,res)=>{
    var user = req.body
    var useremail = user.email;
     sess = req.session;
     
     
    conn.userDetails.find({email:useremail},(err,result)=>{
        if(result.length==0){
            res.send("user does not exist")
        }
        else{
            console.log(user.email)
            console.log(user.password)
            conn.userDetails.find({email:user.email,password:user.password},(err,result)=>{
                if(result.length==0){
                 
                    res.send("email or password wrong")
                }
                else{
                    console.log(result[0].isAgent)
                    
                    if(result[0].isAgent == true){
                        var token = jwt.sign({email:result[0].email,password:result[0].password},'secret')
                        res.send({login:"agent",token:token})
                       
                         sess.atk = token;
                        
                    }
                    else{
                    var token = jwt.sign({email:result[0].email,password:result[0].password},'secret')
                       
                    res.send({login:"user",token:token})
                    sess.utk = token;
                    console.log(sess.utk)
                    console.log(sess)
                        
                     
                    }
                    
                    
                }
            })
        }
    })
  
    
})
rout.get("/tokenCompare",function(req,res){
   sess = req.session 
   sstk = sess.utk
   console.log(sstk)

    // sess = req.session
    // res.send(sess.utk)
    // console.log(sess.utk)
})

module.exports=rout;