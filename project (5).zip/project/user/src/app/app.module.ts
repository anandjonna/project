import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from "@angular/http"
import { AppComponent } from './app.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { ProductComponent } from './product/product.component';
import {RouterModule} from "@angular/router";
import {NgxPaginationModule} from "ngx-pagination";

var obj=[{path:"",component:FrontpageComponent},
       {path:"fp",component:FrontpageComponent},
      { path:"prd",component:ProductComponent}]
    
  var rout=RouterModule.forRoot(obj)  

@NgModule({
  declarations: [
    AppComponent,
    FrontpageComponent,
    ProductComponent
  ],
  imports: [
    BrowserModule,HttpModule,rout,NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
