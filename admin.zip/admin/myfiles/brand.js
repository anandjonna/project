var exp=require("express")
var mj=require("mongojs")
var conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router();
rout.post("/ins_brand",function(req,res){
    ob=req.body
    conn.brand.find().sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0){
            iid=1;
        }
        else{
           var iid=result[0]._id
            iid++
        }
        var obj={_id:iid,bname:ob.bname,active:1}
        conn.brand.insert(obj)
        res.send("inserted successfully")
    })
})

// To get Brand Records
rout.get("/get_brand",function(req,res){
    conn.brand.find(function(err,result){
        res.send(result)
    })
})

//to save updated brand
rout.post("/update_brand",function(req,res){
    ob=req.body
    conn.brand.update({_id:ob[0]._id},{$set:{bname:ob[1].bname}})
    res.send("updated successfully")
})
//inactive and active
rout.post("/inactive",function(req,res){
    idata=req.body
    conn.brand.update({_id:idata._id},{$set:{active:idata.active}})
})
rout.post("/active",function(req,res){
    idata=req.body
    conn.brand.update({_id:idata._id},{$set:{active:idata.active}})
})


module.exports=rout;