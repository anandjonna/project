var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router()
rout.post("/product_ins",function(req,res){
    obj=req.body
    conn.product.find().sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0){
            iid=1
        }
        else{
            iid=result[0]._id
            iid++
        }
        obj1={_id:iid,catid:obj.catid,subcatid:obj.subcatid,subsubcatid:obj.subsubcatid,brandid:obj.brandid,
        productname:obj.pname,pquantity:obj.pquantity,pdesc:obj.pdesc,pprice:obj.pprice,prating:obj.prating,pcolor:obj.pcolor}
        conn.product.insert(obj1)
        res.send("inserted successfully")
    })
    //console.log(obj)
    //conn.product.insert(obj)
})

rout.post("/upimg",function(req,res){
    ob=req.body
    conn.product.find().sort({_id:-1}).limit(1,function(err,result){
        id=result[0]._id
        conn.product.update({_id:id},{$set:{pimg:ob.image}})
        res.send("inserted")
    })
    
})

// To get product details

rout.get("/get_product",function(req,res){
    conn.product.find(function(err,result){
        conn.brand.find(function(err,bresult){
       conn.subsubcat.find(function(err,ssresult){
        conn.subcat_ins.find(function(err,sresult){
            conn.cat_ins.find(function(err,cresult){
                    arr=[];
                    for(i=0;i<result.length;i++){
                       ob={}
                        ob=result[i]
                        for(j=0;j<bresult.length;j++){
                            if(result[i].brandid==bresult[j]._id){
                                ob.bname=bresult[j].bname
                            }
                        }
                        for(k=0;k<ssresult.length;k++){
                            if(result[i].subsubcatid==ssresult[k]._id){
                                ob.subsubcatname=ssresult[k].subsubname
                            }
                        }
                        for(l=0;l<sresult.length;l++){
                            if(result[i].subcatid==sresult[l]._id){
                                ob.subcatname=sresult[l].subcatname
                            }
                        }
                        for(m=0;m<cresult.length;m++){
                            if(result[i].catid==cresult[m]._id){
                                ob.catname=cresult[m].cname
                                arr.push(ob)
                            }
                        }
                    }
                    res.send(arr)

            })
        })
       })
    })
    })
})



module.exports=rout;