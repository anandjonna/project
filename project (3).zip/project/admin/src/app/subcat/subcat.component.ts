import { Component, OnInit,Inject } from '@angular/core';
import { Http} from "@angular/http"
@Component({
  selector: 'app-subcat',
  templateUrl: './subcat.component.html',
  styleUrls: ['./subcat.component.css']
})
export class SubcatComponent implements OnInit {
rst;t1;oldob;newobj
allsubcat;tmp=0;newob;updsel;
catsel;subtxt;vald=1;
  constructor( @Inject (Http) public obj) { }
  getfun(){
    this.obj.get("fi2/subget").subscribe(dtt=>{
      this.allsubcat=JSON.parse(dtt._body)
    })
  }
  updatefun(upd){
    this.tmp=(upd._id)
    this.newob=upd
    this.t1=this.newob.subcatname;
    this.oldob={_id:this.tmp}
    this.updsel=upd.catid
  }
  //===============active, inactive buttons=============

fun_inactive(x,inact){
  x.active=0
  var ob={_id:x._id,active:inact}
  this.obj.post("fi2/inactive",ob).subscribe(
    di=>{
      alert(di._body)
    })
  }
  fun_active(y,act){
    y.active=1
    var ob={_id:y._id,active:act}
    this.obj.post("fi2/active",ob).subscribe(
      di=>{
        alert(di._body)
      })
  }

 funsave(){
 this.newobj={subcatname:this.t1,catid:this.updsel}
 var arr=[this.oldob,this.newobj]
 this.obj.post("fi2/updcat",arr).subscribe(
   upd=>{
     alert(upd._body)
     this.tmp=0
     this.getfun()
   })
  }
  
  ins_sub(fr1){
    if(fr1.valid){
   var sel=this.catsel
    var scat=this.subtxt
     var ob={subcatname:scat,cid:sel}
     this.obj.post("fi2/subins",ob).subscribe(
       dt=>{
       alert(dt._body)
       this.getfun()
       this.subtxt=""
       this.catsel=""
     })
    }
    else{
      this.vald=0;
    }
  }

  ngOnInit() {
    
    this.obj.get("fi1/met2").subscribe(
      dtt=>{
        this.rst=JSON.parse(dtt._body)
        this.getfun()
      })
      
  }

}
