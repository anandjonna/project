var exp=require("express")
rout=exp.Router()
rout.post("/getcartitems",function(req,res){
    var obj=req.body
    var arr=obj.products
    var uid=obj.userid
    console.log(arr)
    var products=[];
    for(var i=0;i<arr.length;i++){
        var obj={};
        obj.pid=arr[i]._id;
        obj.pname=arr[i].productname;
        obj.quantity=arr[i].selqty;
        obj.price=arr[i].pprice;
        obj.color=arr[i].pcolor;
        obj.image=arr[i].pimg;
        products.push(obj)
        
    }
    console.log(products)
    conn.userorders.find().sort({_id:-1}).limit(1,function(err,result){

        if(result==0){
            var id=1
        }
        else{
            id=result[0]._id
            id++
        }
        conn.userorders.insert({_id:id,userid:uid,dt:new Date(),products:products})
         
        res.send("inserted successfully")
    })
   
})
module.exports=rout;