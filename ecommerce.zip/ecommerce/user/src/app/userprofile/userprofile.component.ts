import { Component, OnInit,Inject } from '@angular/core';
import {Router} from "@angular/router";
import {Http} from "@angular/http";
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
change=0;cartarr=[];userorders;user
  constructor(@Inject(Router) public rt,@Inject(Http) public ht) { }
  funOrders(){
    this.change=1;
    this.userorders=JSON.parse(localStorage.getItem("userOrders"))
  }
  funWishlist(){
    this.change=2;
  }
  funCartList(){
    this.change=3;
    this.cartarr=JSON.parse(localStorage.getItem("cart"))
    
  }
  funAccount(){
    this.change=4;
  }
  ngOnInit() {
    if(localStorage.getItem("uname")==null){
      this.rt.navigateByUrl("/")

    
     
    }
    this.user=(localStorage.getItem("uid"))
   
  }

}
