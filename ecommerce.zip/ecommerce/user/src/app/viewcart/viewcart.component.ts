import { Component, OnInit, Inject } from '@angular/core';
import {Http} from "@angular/http";
import {Router} from "@angular/router"

import {ViewcartService} from "../viewcart.service";

@Component({
  selector: 'app-viewcart',
  templateUrl: './viewcart.component.html',
  styleUrls: ['./viewcart.component.css']
})
export class ViewcartComponent implements OnInit {

  constructor( @Inject(Http) public ht,public cart:ViewcartService,private rt:Router) { }
product;arr;tot_cart_items;data;str1;selqty;qtytxt;cartempty=0;




fun_inc(ind,preqty){
  

if(this.data[ind].selqty==preqty)
  alert("exceeded")
  else{
    this.data[ind].selqty++;
    localStorage.setItem("cart",JSON.stringify(this.data))
    
  }
   
  }




fun_dec(ind){
 if(this.data[ind]>1){
   this.data[ind].selqty--;
 }
}

// To Remove cart item
funremove(ind){
  
 this.data.splice(ind,1)
  localStorage.setItem("cart",JSON.stringify(this.data))

  alert("item removed")
  this.cart.funcartobserve(this.data.length.toString())
  if(this.data.length==0){
    localStorage.removeItem("cart")
  }

}



funproceed(){
  if(localStorage.getItem("cart")!=null){
  var arr=this.data;
  var uid=localStorage.getItem("uid")
  alert(uid)
  var obj={products:arr,userid:uid}
  this.ht.post("userorders/getcartitems",obj).subscribe(dt=>{
  alert(dt._body)
})
// this.ht.get("http://www.onlinebulksmslogin.com/spanelv2/api.php?username=nalax&password=nalax@123&to=8297844903&from=TESTIN&message=hi%20your order placed").subscribe(dt=>{
//   alert("message sended successsfully")
// })

localStorage.removeItem("cart")
localStorage.setItem("userOrders",JSON.stringify(this.data))


  //this.rt.navigateByUrl("/success")
  window.location.href="/success";
  this.cartempty=1
}
else{
  alert("your cart is empty add some items")
}
}




sum=0;

cartitemlength

  ngOnInit() {
//  For observables
 
    if(localStorage.getItem("cart")!=null){
      var cartlength=JSON.parse(localStorage.getItem("cart"))
      this.cart.funcartobserve(cartlength.length.toString())
      this.cart.currentItem.subscribe(cartitem=>{
        this.cartitemlength=cartitem
      })
    }

    // To Check login
    
    if(localStorage.getItem("uname")==null){
      this.rt.navigateByUrl("/")
      alert("pleas Login")
    }




    var arr
    arr=localStorage.getItem("cart")
    this.product=arr
    arr=JSON.parse(arr)
    this.data=arr
    if(this.data==null){
      this.cartempty=1;
    }
// for(var i=0;i<this.data.length;i++){
//   var str=this.data[i]
//   if(str.selqty==this.data[i].selqty){
//      this.str1=this.data[i].selqty
//   }
// }
     




// To add cost of all products
if(localStorage.getItem("cart")!=null){
var str=[]
  for(var i=0;i<this.data.length;i++){
       var rate=this.data[i]
       str[i]=rate.pprice*this.data[i].selqty
       }

  
  for(var j=0;j<str.length;j++){
    this.sum += parseInt(str[j])
  }
  

  }
}

}
