import { Component,Inject,OnInit } from '@angular/core';
import { Http } from "@angular/http"
import {trigger,animate,state,style,transition} from "@angular/animations";
import {Router} from "@angular/router"
import {ViewcartService} from "./viewcart.service"

var myanimations=[trigger("anm1",
[state("st1",style({top:'100px'})),
state("st2",style({top:'-700px'})),
transition("*=>*",animate("100ms"))]
)]

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations:[myanimations]
})
export class AppComponent {
  title = 'app';
  cdata;sdata;ssdata;tmp="st2";change=1;pfdd=0;
  uname;pwd;rpwd;em;mbno;searchtxt;luname;lpwd;log_in_out=1;searchdata;sdrp=1;npwd;nrpwd



  constructor(@Inject(Http) public obj,@Inject(Router) public rt,public cart:ViewcartService){}



  // For register User details
  fun_reg(){
    var ob={uname:this.uname,password:this.pwd,rpassword:this.rpwd,email:this.em,mobileno:this.mbno}
    alert(ob)
    this.obj.post("reg_ref/Register",ob).subscribe(
      x=>{
        alert(x._body)
      })
  }
  //For search Results
  fun_search(){
    if(this.searchtxt.length==0){
      this.sdrp=0;
    }
    else{
      this.sdrp=1
   var ob={pname:this.searchtxt}
   this.obj.post("product_ref/get_product",ob).subscribe(x=>{
     this.searchdata=JSON.parse(x._body)
    
    })
  }
  }
//To logout
  logout(){
    localStorage.removeItem("uname")
    localStorage.removeItem("uid")
    this.log_in_out=1;
    this.tmp="st2"
    this.rt.navigateByUrl("/")
  }
//For Login 
  login(){
var ob={uname:this.luname,password:this.lpwd}
this.obj.post("log_ref/login",ob).subscribe(
  x=>{
    var rst=JSON.parse(x._body)
    if(rst.count==0){
      alert("Invalid username/password")
    }
    else{
      
      this.log_in_out=0;
      this.tmp='st2'
      var uname=(rst.token)
      localStorage.setItem("uname",uname)
      localStorage.setItem("uid",rst.uname)
    }
  }
)
  }
  //To change the template and hide using animate
  register(){
    this.tmp="st1"
    this.change=0;
  }
//To change the template and hide using animate
  login_fun(){
    this.tmp='st1';
    this.change=1;
  }
  //To change the template and hide using animate
  changepassword(){
    this.tmp="st1"
    this.change=2;
    this.pfdd=0;
  }
  //To update the new password values
  savepassword(){
   var loginuname=(localStorage.getItem("uname"))
    var ob={uname:loginuname}
    var newpwd={password:this.npwd}
     var arr=[ob,newpwd]
    this.obj.post("log_ref/changepwd",arr).subscribe(x=>{
      alert(x._body)
      this.tmp="st2"
      
    })
  }
  cartitemlength

  fun_validate()
{
  
  var token=localStorage.getItem("uname")
  var key={utoken:token}
  
  this.obj.post("log_ref/validate_token",key).subscribe(conf=>{
    var cnt=JSON.parse(conf._body)
    alert(cnt.count)
   if(cnt.count==1){
    this.rt.navigateByUrl("/up")
    
  }
  else{
    this.rt.navigateByUrl("/")
    
  }
    
  })
}

ngOnInit(){
 
  if(localStorage.getItem("uname")!=null){
    this.log_in_out=0
  }
  this.obj.get("cat_ref/cat_get").subscribe(
      dt=>{
        this.cdata=JSON.parse(dt._body)
        
      })

  this.obj.get("subcat_ref/subcat_get").subscribe(
    dt=>{
      this.sdata=JSON.parse(dt._body)
     
    })
      
    this.obj.get("subsubcat_ref/subsubcat_get").subscribe(
      dt=>{
        this.ssdata=JSON.parse(dt._body)
      })

      if(localStorage.getItem("cart")!=null){
        var cartlength=JSON.parse(localStorage.getItem("cart"))
        this.cart.funcartobserve(cartlength.length.toString());

       
      }
      this.cart.currentItem.subscribe(cartitem=>{
        this.cartitemlength=cartitem;
      })
   

  }
}
