var exp=require("express")
rout=exp.Router();
rout.post("/Register",function(req,res){
    ob=req.body
    conn.reg.insert(ob)
    res.send("registration successful")
})

module.exports=rout;