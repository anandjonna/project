var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rout=exp.Router()
rout.get("/subsubcat_get",function(req,res){
conn.subsubcat.find(function(err,result){
    res.send(result)
})
})
module.exports=rout