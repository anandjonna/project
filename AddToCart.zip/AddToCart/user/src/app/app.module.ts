import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from "@angular/http"
import { AppComponent } from './app.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { ProductComponent } from './product/product.component';
import {RouterModule} from "@angular/router";
import {NgxPaginationModule} from "ngx-pagination";
import {Ng2SearchPipeModule} from "ng2-search-filter"
import {FormsModule} from "@angular/forms";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {OrderModule} from "ngx-order-pipe";
import { UserprofileComponent } from './userprofile/userprofile.component';
import { MoreComponent } from './more/more.component';
import { ViewcartComponent } from './viewcart/viewcart.component';

var obj=[{path:"",component:ProductComponent},
       {path:"fp",component:FrontpageComponent},
      { path:"prd",component:ProductComponent},
      { path:"up",component:UserprofileComponent},
      { path:"more",component:MoreComponent},
      { path:"viewcart",component:ViewcartComponent}]
    
  var rout=RouterModule.forRoot(obj)  

@NgModule({
  declarations: [
    AppComponent,
    FrontpageComponent,
    ProductComponent,
    UserprofileComponent,
    MoreComponent,
    ViewcartComponent
  ],
  imports: [
    BrowserModule,HttpModule,rout,NgxPaginationModule,Ng2SearchPipeModule,FormsModule,BrowserAnimationsModule,OrderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
