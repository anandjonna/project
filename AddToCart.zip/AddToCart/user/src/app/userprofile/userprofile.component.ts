import { Component, OnInit,Inject } from '@angular/core';
import {Router} from "@angular/router";
import {Http} from "@angular/http";
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  constructor(@Inject(Router) public rt,@Inject(Http) public ht) { }

  ngOnInit() {
    if(localStorage.getItem("uname")==null){
      this.rt.navigateByUrl("/")
     
    }
    var token=localStorage.getItem("uname")
    var key={utoken:token}
    this.ht.post("log_ref/validate_token",key).subscribe(conf=>{
      alert(conf._body)
     if(conf._body="succcess "){
      this.rt.navigateByUrl("/up")
      
    }
    else{
      this.rt.navigateByUrl("/")
      
    }
      
    })
  }

}
