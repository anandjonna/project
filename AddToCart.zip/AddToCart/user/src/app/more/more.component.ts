import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import {Http} from "@angular/http"
@Component({
  selector: 'app-more',
  templateUrl: './more.component.html',
  styleUrls: ['./more.component.css']
})
export class MoreComponent implements OnInit {
moredata;qtytxt=1;halfstar=0;
  constructor( @Inject(ActivatedRoute) public ar,@Inject(Http) public ht) { 
//localStorage.removeItem("cart")
  }

 arr
 localdata
funaddcart(product){
  var arr=[];var newarr=[]
  this.qtytxt++
this.localdata=JSON.parse(localStorage.getItem("cart"))
if(this.localdata!=null){
  arr=JSON.parse(localStorage.getItem("cart"))
  product.selqty=this.qtytxt
  var str='\\"_id\\":'+product._id+",";
  alert(str)
  if(localStorage.getItem('cart').indexOf(str)){
    for(var i=0;i<arr.length;i++){
      var str1=JSON.parse(arr[i])
      if(str1._id==product._id){
        str1.selqty=product.selqty
        alert("updated product")
      }
      else{
        newarr.push(JSON.stringify(str1))
      }
    }
  }
  newarr.push(JSON.stringify(product));


  // for(var i=0;i<this.localdata.length;i++){
  //   if(this.localdata[i].id==obj.id){
  //     this.localdata[i].qty++
     
  //   }
    //  else{
    //   this.localdata.push(obj)
    //  }
    //  localStorage.setItem("cart",JSON.stringify(this.localdata))
    //   }
      
    
      
     
}
else{
  product.selqty=this.qtytxt
  newarr.push(JSON.stringify(product))
}
localStorage.setItem("cart",JSON.stringify(newarr))

// else{
//   var fob=[{id:prodid,qty:1}]
//   localStorage.setItem("cart",JSON.stringify(fob))
// }

}

fun_inc(qty){
 
  if(this.qtytxt<qty)
  this.qtytxt++;
 else
 alert("exceeded")
}
fun_dec(){
  if(this.qtytxt>1)
  this.qtytxt--;
  else
  alert("quantity should not be lessthan 1")
}
ratearr=[]
  ngOnInit() {
    this.ar.params.subscribe(x=>{
      var prodid=parseInt(x["id"])
      var ob={_id:prodid}
      var product=localStorage.getItem("cart")
        
        this.ht.post("product_ref/get_more",ob).subscribe(x=>{
          this.moredata=JSON.parse(x._body)
         var rating=(this.moredata[0].prating)
         this.ratearr=[]
          for(var i=1;i<=rating;i++){
              this.ratearr.push(i)
          }
          i--;
          if(rating>i){
            this.halfstar=1
          }
         
        })
    })
  }

}
