import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import {Http} from "@angular/http"

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
subsubid;newproduct;runproduct;prodid;
  constructor(@Inject(Http) public obj,@Inject(ActivatedRoute) public ar) { }

  ngOnInit() {
   this.obj.get("product_ref/getnew_product").subscribe(x=>{
     this.newproduct=JSON.parse(x._body)
     
   })
   this.obj.get("product_ref/getrun_product").subscribe(x=>{
    this.runproduct=JSON.parse(x._body)
    
  })
  this.ar.params.subscribe(x=>{
    this.prodid=x["_id"]
  })
  }

}
