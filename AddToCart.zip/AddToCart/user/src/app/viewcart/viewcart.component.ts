import { Component, OnInit, Inject } from '@angular/core';
import {Http} from "@angular/http";

@Component({
  selector: 'app-viewcart',
  templateUrl: './viewcart.component.html',
  styleUrls: ['./viewcart.component.css']
})
export class ViewcartComponent implements OnInit {

  constructor( @Inject(Http) public ht) { }
product;arr;tot_cart_items;data;str1;selqty;qtytxt
fun_inc(qty,prevqunatity){
  
 this.qtytxt=prevqunatity
  if(this.data.qtytxt<qty)
  this.selqty++;
 else
 alert("exceeded")
}
fun_dec(){
  if(this.qtytxt>1)
  this.selqty--;
  else
  alert("quantity should not be lessthan 1")
}
funremove(id){
  alert(JSON.parse(id))
  var td=localStorage.getItem("cart")
  alert(JSON.parse(td[0]))
alert("removed")
}
funproceed(){
  this.ht.get("log_ref/sms").subscribe(dt=>{
    
  })
}
  ngOnInit() {
    var arr
    arr=localStorage.getItem("cart")
    this.product=arr
    arr=arr.replace(/\\/g,"")
    arr=arr.replace(/"{/g,"{") 
    arr=arr.replace(/}"/g,"}")
    arr=JSON.parse(arr)
    this.tot_cart_items=arr.length

  this.data=arr

// for(var i=0;i<this.data.length;i++){
//   var str=this.data[i]
//   if(str.selqty==this.data[i].selqty){
//      this.str1=this.data[i].selqty
//   }
// }
    
  }

}
