var exp=require("express")
var mj=require("mongojs")
rout=exp.Router()
conn=mj("mongodb://localhost:27017/cat")
rout.post("/met1",function(req,res){
ob=req.body
var id=conn.cat_ins.find().sort({_id:-1}).limit(1,function(err,result){
   if(result.length==0)
       iid=1
       else{
          var iid=(result[0]._id)
           iid++
       }
       uid={_id:iid,cname:ob.uname,active:1}
    conn.cat_ins.insert(uid)
    res.send("inserted successfully")
}
)
})
rout.get("/met2",function(req,res){
    conn.cat_ins.find(function(err,rs){
        res.send(rs)
    })
})
rout.post("/rem",function(re,rs){
    od=re.body
    conn.cat_ins.remove(od)
    rs.send("deleted")
})

rout.post("/upct",function(req,res){
  cdt=req.body
  conn.cat_ins.update(cdt[0],{$set:cdt[1]})
  res.send("updated successfully")    
})

//===============active, inactive buttons=============

rout.post("/inactive",function(req,res){
    idata=req.body
    conn.cat_ins.update({_id:idata._id},{$set:{active:idata.active}})
})
rout.post("/active",function(req,res){
    idata=req.body
    conn.cat_ins.update({_id:idata._id},{$set:{active:idata.active}})
})

//=========================catfile.js==============

module.exports=rout