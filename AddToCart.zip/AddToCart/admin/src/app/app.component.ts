import { Component,Inject } from '@angular/core';
import {Http} from "@angular/http"
import {Router} from "@angular/router"
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  aname;apwd;logdata=0;loginsuccess=1;
  constructor(@Inject(Http) public ht,@Inject(Router) public rt) { }
login(){
var ob={aname:this.aname,password:this.apwd}
this.ht.post("login_ref/login",ob).subscribe(x=>{
   var lrs=JSON.parse(x._body)
if(lrs.count==0){
  alert("invalide username/password")
}
else{
  localStorage.setItem("aname",this.aname)
  alert(localStorage.getItem("aname"))
  this.logdata=1;
  this.loginsuccess=0;
  this.rt.navigateByUrl("login")
}

})
}
logout(){
 localStorage.removeItem("aname")
 this.loginsuccess=1
 this.logdata=0;
 this.rt.navigateByUrl("/")

}
ngOnInit(){
  if(localStorage.getItem("aname")==null){

     
  }
  else{
    
  }
}
}
