import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms";
import { AppComponent } from './app.component';
import { CatComponent } from './cat/cat.component';
import { SubcatComponent } from './subcat/subcat.component';
import { SubsubcatComponent } from './subsubcat/subsubcat.component';
import { BrandComponent } from './brand/brand.component';
import { ProductComponent } from './product/product.component';
import  {RouterModule} from '@angular/router';
import {HttpModule} from "@angular/http";
import {NgxPaginationModule} from "ngx-pagination"
import {Ng2OrderModule} from "ng2-order-pipe";
import { LoginComponent } from './login/login.component';

var obj=[{
  path:"",component:AppComponent
},{
  path:"cat",component:CatComponent
},{
  path:"subcat",component:SubcatComponent
},{
  path:"subsubcat",component:SubsubcatComponent
},{
  path:"brand",component:BrandComponent
},{
  path:"product",component:ProductComponent
},{
  path:"login",component:LoginComponent
}]
var rout=RouterModule.forRoot(obj)

@NgModule({
  declarations: [
    AppComponent,
    CatComponent,
    SubcatComponent,
    SubsubcatComponent,
    BrandComponent,
    ProductComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,rout,HttpModule,FormsModule,NgxPaginationModule,Ng2OrderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
