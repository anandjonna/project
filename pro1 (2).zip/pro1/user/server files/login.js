var exp=require("express")
rout=exp.Router()
rout.post("/login",function(req,res){
    rdt=req.body
    conn.reg.find(rdt).count(function(err,result){
        res.send({count:result})
    })
})
module.exports=rout;