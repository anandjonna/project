import { Component, OnInit,Inject } from '@angular/core';
import {Http } from "@angular/http";
@Component({
  selector: 'app-brand',
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.css']
})
export class BrandComponent implements OnInit {
brrec;tmp=0;oldob;upbr;newob;
  constructor( @Inject(Http) public obj) { }
  br1;vald=1;pno=1;
  fun_brand_ins(fr1){
    if(fr1.valid){
    var ob={bname:this.br1}
    this.obj.post("fi4/ins_brand",ob).subscribe(
      dbr=>{
       alert(dbr._body)
       this.br1=""
       this.fun_brand_get()
      })
  }
  else{
    this.vald=0;
  }
}  
  fun_brand_get(){
    this.obj.get("fi4/get_brand").subscribe(
      gb=>{
        this.brrec=JSON.parse(gb._body)
      })
  }

  fun_inactive(x,inact){
    x.active=0
    var ob={_id:x._id,active:inact}
    this.obj.post("fi4/inactive",ob).subscribe(
      di=>{
        alert(di._body)
      })
    }
    fun_active(y,act){
      y.active=1
      var ob={_id:y._id,active:act}
      this.obj.post("fi4/active",ob).subscribe(
        di=>{
          alert(di._body)
        })
    }

  brand_update(ob){
    this.tmp=ob._id
    this.oldob={_id:this.tmp}
  }
  fun_save(){
  this.newob={bname:this.upbr}
   var arr=[this.oldob,this.newob] 
  this.obj.post("fi4/update_brand",arr).subscribe(
    ubr=>{
      alert(ubr._body)
      this.tmp=0;
      this.fun_brand_get()
    })
  }

  ngOnInit() {
    this.fun_brand_get()
  }

}
