import { Component, OnInit,Inject } from '@angular/core';
import {Http} from "@angular/http" 
import {OrderModule} from "ngx-order-pipe"

@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {
 catxt=""
 obt;vald=1
 rst;cdt;ctxt;
 rd;tmp=0;oldobj;newobj;pno=1;tmp1=true;key;
  constructor(@Inject(Http) public obj) { }

  funsort(key){
    this.key=key;
    this.tmp1=!this.tmp1
 // if(this.tmp1==true){
   // this.tmp1=false;
  //}
  //else{
   // this.tmp1=true;
  //}
   
  }


//update 
updfun(cd){
  this.tmp=cd._id
    this.cdt=cd
    this.ctxt=cd.cname;
}
//updated values insertion
savefun(){
  this.oldobj={_id:this.tmp}
  this.newobj={cname:this.ctxt}
  var arr=[this.oldobj,this.newobj]
  this.obj.post("fi1/upct",arr).subscribe(
    cdt=>{
      alert(cdt._body)
    })
    this.tmp=0
    this.getfun()
}


//===============active, inactive buttons=============

fun_inactive(x,inact){
x.active=0
var ob={_id:x._id,active:inact}
this.obj.post("fi1/inactive",ob).subscribe(
  di=>{
    alert(di._body)
  })
}
fun_active(y,act){
  y.active=1
  var ob={_id:y._id,active:act}
  this.obj.post("fi1/active",ob).subscribe(
    di=>{
      alert(di._body)
    })
}

//=========================cat.component.ts==============

  catdel(d){
  var  obd={_id:d}
    this.obj.post("fi1/rem",obd).subscribe(
      dd=>{
    alert(dd._body)
    })
    this.getfun()
  }
  insfun(fm1){
    if(fm1.valid){
      this.vald=1
    var obt={uname:this.catxt}
    this.obj.post("fi1/met1",obt).subscribe(dt=>{
      alert(dt._body)
      this.getfun()
       }) 
    this.catxt=""
  }
  else{
    this.vald=0;
  }

}
  ngOnInit() {
    this.getfun()
  }
    getfun(){
      this.obj.get("fi1/met2").subscribe(
        dtt=>{
          this.rst=JSON.parse(dtt._body)
        })
    }
  
 

}
