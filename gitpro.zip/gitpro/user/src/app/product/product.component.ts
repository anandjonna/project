import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
subsubid;
  constructor(@Inject(ActivatedRoute) public obj) { }

  ngOnInit() {
    alert("hi")
    this.obj.params.subscribe(x=>{
      this.subsubid=x["_id"]
      var ob={subsubcatid:this.subsubid}
      this.obj.post("product_ref/getproduct",ob).subscribe(dt=>{
        alert(dt._body)
      })
    })
  }

}
