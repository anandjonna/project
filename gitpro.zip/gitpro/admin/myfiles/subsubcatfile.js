var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rut=exp.Router()

//getting subsubcat records
rut.get("/getssub",function(req,res){
    conn.subsubcat.find(function(err,ssresult){
        conn.subcat_ins.find(function(err,sresult){
            conn.cat_ins.find(function(err,cresult){
                arr=[]
                for(i=0;i<ssresult.length;i++){
                    ob={}
                    ob=ssresult[i]
                    for(j=0;j<sresult.length;j++){
                        if(ssresult[i].subcatid==sresult[j]._id){
                            ob.subcatname=sresult[j].subcatname
                            break;
                        } 
                    }
                    for(k=0;k<cresult.length;k++){
                        if(ssresult[i].catid==cresult[k]._id){
                            ob.catname=cresult[k].cname
                            break;
                        }
                    }
                    arr.push(ob)
                }
                res.send(arr)
            })
        })
    })
})

rut.post("/subsubins",function(req,res){
    ob=req.body;
    conn.subsubcat.find().sort({_id:-1}).limit(1,function(err,result){
        if(result.length==0){
            iid=1
        }
        else{
            iid=result[0]._id
            iid++
        }
        ssid={_id:iid,catid:ob.catid,subcatid:ob.scatid,subsubname:ob.ssubcatname,active:1}
        conn.subsubcat.insert(ssid)
        res.send("inserted succesfully")
    })
   /* conn.subsubcat.insert(obj)
    res.send("Inserted successfully")*/
})
rut.post("/subsubsave",function(req,res){
ob=req.body;
conn.subsubcat.update(ob[0],{$set:ob[1]})
res.send("updated successfully")
})

rut.post("/inactive",function(req,res){
    idata=req.body
    conn.subsubcat.update({_id:idata._id},{$set:{active:idata.active}})
})
rut.post("/active",function(req,res){
    idata=req.body
    conn.subsubcat.update({_id:idata._id},{$set:{active:idata.active}})
})


//to get subsubcategory name based on subcategory name
rut.post("/subsubdet",function(req,res){
    scid=req.body
    conn.subsubcat.find({subcatid:scid.subcatid},function(err,result){
        res.send(result)
    })
})


module.exports=rut;