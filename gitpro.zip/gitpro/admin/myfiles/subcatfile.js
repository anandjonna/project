var exp=require("express")
var mj=require("mongojs")
conn=mj("mongodb://localhost:27017/cat")
rut=exp.Router()
/*
rut.get("/met2",function(re,rs){
    conn.cat_ins.find(function(err,res){
        rs.send(res)
    })
})*/
rut.post("/subins",function(req,res){
  sd=req.body
  conn.subcat_ins.find().sort({_id:-1}).limit(1,function(err,rt){
      if(rt.length==0)
          iid=1
      else{
          var iid=(rt[0]._id)
          iid++
      }
     var sdt={_id:iid,subcatname:sd.subcatname,catid:sd.cid,active:1}
     conn.subcat_ins.insert(sdt)
     res.send("inserted successfully")
  })
})


  rut.get("/subget",function(rq,rsp){
    conn.subcat_ins.find(function(err,subresult){
        conn.cat_ins.find(function(err,catresult){
        var arr=[]
        for(var i=0;i<subresult.length;i++){
            for(var j=0;j<catresult.length;j++){
                if(subresult[i].catid==catresult[j]._id){
                            obj=subresult[i]
                            obj.cname=catresult[j].cname
                            arr.push(obj)
                }
            }
        }
        rsp.send(arr)
    })
      })
  })




  rut.post("/getsub",function(rqt,rsc){
      sdt=(rqt.body)
      conn.subcat_ins.find({catid:sdt.cid},function(err,cresult){ 
        rsc.send(cresult)
      })
  })

 rut.post("/updcat",function(rq,rs){
     uprc=rq.body
     console.log(uprc)
     conn.subcat_ins.update(uprc[0],{$set:uprc[1]})
     rs.send("updated successfully")
 })

 rut.post("/inactive",function(req,res){
    idata=req.body
    conn.subcat_ins.update({_id:idata._id},{$set:{active:idata.active}})
})
rut.post("/active",function(req,res){
    idata=req.body
    conn.subcat_ins.update({_id:idata._id},{$set:{active:idata.active}})
})



module.exports=rut;